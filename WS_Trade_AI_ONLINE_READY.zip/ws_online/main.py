
import base64
import json
import os
import sqlite3
from datetime import datetime

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import FileResponse
from openai import OpenAI

BASE = os.path.dirname(os.path.abspath(__file__))
STATIC = BASE
DB = os.path.join(BASE, "trade_ai.db")

app = FastAPI(title="WS Trade AI V2")
def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = db()
    c.execute("""CREATE TABLE IF NOT EXISTS analyses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        filename TEXT,
        asset TEXT,
        timeframe TEXT,
        signal TEXT,
        score INTEGER,
        analysis TEXT
    )""")
    c.commit()
    c.close()

init_db()

PROMPT = r"""
Você é o motor de análise técnica do WS Trade AI.

Analise exclusivamente o que estiver visível no print. Não invente preço,
indicadores, volume ou níveis que não aparecem.

O objetivo é classificar o cenário em COMPRA, VENDA ou AGUARDAR.
A classificação deve ser conservadora: quando a evidência for insuficiente,
prefira AGUARDAR.

Avalie estes fatores, atribuindo de 0 a 20 pontos:
1) Tendência
2) Estrutura/topos e fundos
3) Suporte/resistência
4) Candles e reação do preço
5) Momentum/indicadores visíveis

O SCORE FINAL é a soma dos 5 fatores, de 0 a 100.
Não confunda score de qualidade do cenário com probabilidade de vitória.

Retorne SOMENTE JSON válido neste formato:
{
  "signal": "COMPRA|VENDA|AGUARDAR",
  "score": 0,
  "trend": "ALTA|BAIXA|LATERAL|INDEFINIDA",
  "entry": "texto curto",
  "target_or_expiration": "texto curto",
  "support": "texto curto",
  "resistance": "texto curto",
  "factors": {
    "trend": 0,
    "structure": 0,
    "support_resistance": 0,
    "candles": 0,
    "momentum": 0
  },
  "reasons": ["...", "...", "..."],
  "invalidation": "texto curto",
  "confidence_note": "texto curto"
}

Se não houver dados suficientes para sugerir uma entrada, use "não definida".
Não forneça garantia de lucro. Para operações de tempo fixo, trate
expiração apenas como cenário técnico, nunca como garantia.
"""

def parse_json(text):
    text = text.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1]
        text = text.rsplit("```", 1)[0]
    return json.loads(text)

@app.get("/")
def index():
    return FileResponse(os.path.join(STATIC, "index.html"))

@app.get("/api/history")
def history():
    c = db()
    rows = c.execute("""SELECT id, created_at, asset, timeframe, signal, score
                        FROM analyses ORDER BY id DESC LIMIT 30""").fetchall()
    c.close()
    return [dict(r) for r in rows]

@app.delete("/api/history")
def clear_history():
    c = db()
    c.execute("DELETE FROM analyses")
    c.commit()
    c.close()
    return {"ok": True}

@app.post("/api/analyze")
async def analyze(file: UploadFile = File(...), asset: str = "", timeframe: str = ""):
    if not file.content_type or not file.content_type.startswith("image/"):
        raise HTTPException(400, "Envie um print de imagem.")
    data = await file.read()
    if len(data) > 10 * 1024 * 1024:
        raise HTTPException(413, "Imagem acima de 10 MB.")

    key = os.getenv("OPENAI_API_KEY")
    if not key:
        return {
            "demo": True,
            "result": {
                "signal": "AGUARDAR",
                "score": 0,
                "trend": "INDEFINIDA",
                "entry": "não definida",
                "target_or_expiration": "não definido",
                "support": "não avaliado",
                "resistance": "não avaliada",
                "factors": {"trend":0,"structure":0,"support_resistance":0,"candles":0,"momentum":0},
                "reasons": ["Configure OPENAI_API_KEY para ativar a análise real.", "O MVP está funcionando em modo demonstração."],
                "invalidation": "Não operar em modo demonstração.",
                "confidence_note": "Sem análise real."
            }
        }

    client = OpenAI(api_key=key)
    model = os.getenv("OPENAI_MODEL", "gpt-5.6-luna")
    mime = file.content_type
    b64 = base64.b64encode(data).decode()
    response = client.responses.create(
        model=model,
        input=[{
            "role": "user",
            "content": [
                {"type": "input_text", "text": PROMPT + f"\nAtivo informado: {asset or 'não informado'}\nTimeframe informado: {timeframe or 'não informado'}"},
                {"type": "input_image", "image_url": f"data:{mime};base64,{b64}"}
            ]
        }]
    )
    try:
        result = parse_json(response.output_text)
    except Exception:
        raise HTTPException(502, "A IA retornou um formato que não pôde ser interpretado.")

    c = db()
    c.execute("""INSERT INTO analyses
        (created_at, filename, asset, timeframe, signal, score, analysis)
        VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (datetime.now().isoformat(timespec="seconds"), file.filename, asset,
         timeframe, result.get("signal"), int(result.get("score", 0)),
         json.dumps(result, ensure_ascii=False)))
    c.commit()
    c.close()

    return {"demo": False, "model": model, "result": result}
